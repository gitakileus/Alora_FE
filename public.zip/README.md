<img align="center" src="/assets/logo.png" height="75" alt="ALORANODE" />
<br />

# ALORANODE FRONTEND

## Requirements
* NPM
* Node 12
